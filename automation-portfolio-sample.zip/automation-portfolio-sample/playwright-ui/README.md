# Playwright UI Automation Sample

실제 가맹점/결제창 대신 가상의 Payment Demo 페이지를 대상으로 작성한
Playwright 테스트 구조 예제입니다.

주요 포인트:
- Page Object 분리
- 사용자 Flow와 Assertion 분리
- 통신사 선택 / 정보 입력 / 인증 / 결제 완료 검증
