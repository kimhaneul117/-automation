import { expect } from '@playwright/test';

export class PaymentPage {
  constructor(page) {
    this.page = page;
    this.carrier = page.getByLabel('통신사선택');
    this.phoneNumber = page.getByLabel('휴대폰번호');
    this.requestOtpButton = page.getByRole('button', { name: '인증번호 요청' });
    this.otp = page.getByLabel('인증번호');
    this.payButton = page.getByRole('button', { name: '결제하기' });
    this.resultMessage = page.locator('[data-testid="payment-result"]');
  }

  async selectCarrier(value) {
    await this.carrier.selectOption(value);
  }

  async enterUserInfo({ phoneNumber }) {
    await this.phoneNumber.fill(phoneNumber);
  }

  async requestOtp() {
    await this.requestOtpButton.click();
  }

  async enterOtp(otp) {
    await this.otp.fill(otp);
  }

  async pay() {
    await this.payButton.click();
  }

  async expectSuccess() {
    await expect(this.resultMessage).toHaveText('결제가 완료되었습니다.');
  }
}
