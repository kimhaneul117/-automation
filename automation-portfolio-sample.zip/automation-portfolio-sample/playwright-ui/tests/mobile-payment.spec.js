import { test, expect } from '@playwright/test';
import { PaymentPage } from '../pages/PaymentPage.js';

test('휴대폰 결제 정상 시나리오', async ({ page }) => {
  const payment = new PaymentPage(page);

  await page.goto('/payment-demo');

  await payment.selectCarrier('SAMPLE');
  await payment.enterUserInfo({
    phoneNumber: '01000000000'
  });

  await payment.requestOtp();

  await expect(page.locator('[data-testid="otp-timer"]'))
    .toHaveText(/^\d{2}:\d{2}$/);

  await payment.enterOtp('000000');
  await payment.pay();
  await payment.expectSuccess();
});
