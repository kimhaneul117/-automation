export function validateResponse(actual, expected) {
  for (const [key, expectedValue] of Object.entries(expected)) {
    const fieldMap = {
      result: 'RESULT',
      transactionId: 'TID'
    };

    const actualKey = fieldMap[key] ?? key;
    const actualValue = actual[actualKey];

    if (expectedValue === 'required') {
      if (actualValue === undefined || actualValue === null || actualValue === '') {
        throw new Error(`${actualKey} is required`);
      }
      continue;
    }

    if (actualValue !== String(expectedValue)) {
      throw new Error(
        `${actualKey}: expected "${expectedValue}", received "${actualValue}"`
      );
    }
  }
}
