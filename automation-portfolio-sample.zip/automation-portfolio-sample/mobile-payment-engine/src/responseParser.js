export function parseResponse(stdout) {
  return stdout
    .split(';')
    .filter(Boolean)
    .reduce((result, pair) => {
      const [key, ...rest] = pair.split('=');
      result[key.trim()] = rest.join('=').trim();
      return result;
    }, {});
}
