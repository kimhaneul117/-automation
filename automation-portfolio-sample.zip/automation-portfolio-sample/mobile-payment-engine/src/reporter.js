import fs from 'node:fs';
import path from 'node:path';

export function writeReport(scenarioName, results) {
  const reportDir = path.resolve('reports');
  fs.mkdirSync(reportDir, { recursive: true });

  const report = {
    scenario: scenarioName,
    executedAt: new Date().toISOString(),
    summary: {
      total: results.length,
      passed: results.filter(result => result.status === 'PASS').length,
      failed: results.filter(result => result.status === 'FAIL').length
    },
    results
  };

  const outputPath = path.join(reportDir, `${scenarioName}.json`);
  fs.writeFileSync(outputPath, JSON.stringify(report, null, 2), 'utf8');

  return outputPath;
}
