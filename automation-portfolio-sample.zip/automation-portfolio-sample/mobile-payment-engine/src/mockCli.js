function createTransactionId() {
  const timestamp = new Date()
    .toISOString()
    .replace(/\D/g, '')
    .slice(0, 14);

  return `SAMPLE${timestamp}`;
}

export async function executeMockCommand(command, params) {
  await new Promise(resolve => setTimeout(resolve, 100));

  const response = {
    RESULT: 'SUCCESS',
    COMMAND: command,
    TID: createTransactionId(),
    AMOUNT: params.amount ?? 0,
    DATE: new Date().toISOString()
  };

  // 실제 업무에서는 child_process로 CLI 실행 후 stdout을 받는 구조를
  // 사용할 수 있으나, 포트폴리오 예제에서는 Mock 응답으로 대체합니다.
  return Object.entries(response)
    .map(([key, value]) => `${key}=${value}`)
    .join(';');
}
