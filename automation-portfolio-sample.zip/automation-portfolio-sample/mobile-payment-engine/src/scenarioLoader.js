import fs from 'node:fs';
import YAML from 'yaml';

export function loadScenario(fileUrl) {
  const raw = fs.readFileSync(fileUrl, 'utf8');
  const scenario = YAML.parse(raw);

  if (!scenario?.name || !Array.isArray(scenario.steps)) {
    throw new Error('Invalid scenario format');
  }

  return scenario;
}
