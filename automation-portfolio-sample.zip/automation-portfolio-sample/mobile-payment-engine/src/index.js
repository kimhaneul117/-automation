import { loadScenario } from './scenarioLoader.js';
import { executeMockCommand } from './mockCli.js';
import { parseResponse } from './responseParser.js';
import { validateResponse } from './validator.js';
import { writeReport } from './reporter.js';

const scenario = loadScenario(
  new URL('../scenarios/payment-success.yaml', import.meta.url)
);

const results = [];

for (const [index, step] of scenario.steps.entries()) {
  const stdout = await executeMockCommand(step.command, step.params ?? {});
  const actual = parseResponse(stdout);

  try {
    validateResponse(actual, step.expect ?? {});
    results.push({
      step: index + 1,
      command: step.command,
      status: 'PASS',
      actual
    });
  } catch (error) {
    results.push({
      step: index + 1,
      command: step.command,
      status: 'FAIL',
      error: error.message,
      actual
    });
  }
}

const reportPath = writeReport(scenario.name, results);
console.table(results.map(({ step, command, status }) => ({ step, command, status })));
console.log(`Report: ${reportPath}`);

if (results.some(result => result.status === 'FAIL')) {
  process.exitCode = 1;
}
