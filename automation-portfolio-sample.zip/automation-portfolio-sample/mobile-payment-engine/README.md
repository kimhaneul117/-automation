# Mobile Payment Scenario Engine

실무에서 경험한 CLI 기반 결제 자동화 구조를 포트폴리오용으로 단순화한 예제입니다.

## Flow

```text
YAML Scenario
      ↓
ScenarioEngine
      ↓
Mock CLI 실행
      ↓
stdout Parsing
      ↓
Assertion
      ↓
JSON Report
```

## Run

```bash
npm install
npm run mobile
```

실제 `SClient.exe`, `dncrypto.exe` 및 결제 전문은 포함하지 않습니다.
