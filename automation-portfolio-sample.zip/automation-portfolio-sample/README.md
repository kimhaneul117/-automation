# 김하늘 | QA Automation Portfolio Sample

> 품질을 검증하는 것을 넘어, 검증 체계를 만드는 QA Engineer

이 저장소는 실무에서 경험한 테스트 자동화 접근 방식을 **개인 환경에서 재구성한 포트폴리오용 샘플**입니다.

> **Security Notice**
> 실제 회사 소스 코드, 사내 URL/IP, 인증정보, 테스트 계정, 결제 전문,
> 비즈니스 로직 및 내부 실행 파일은 포함하지 않습니다.

## Projects

### 1. mobile-payment-engine
YAML로 테스트 시나리오를 정의하고 Node.js 엔진이 이를 읽어
Mock CLI를 실행한 뒤 응답을 파싱·검증하고 리포트를 생성하는 예제입니다.

### 2. playwright-ui
가상의 결제 페이지를 대상으로 한 Playwright UI 자동화 예제입니다.

### 3. api-automation
API 응답값, 필수 필드, 시간값 등을 검증하는 JavaScript Assertion 예제입니다.

## Tech Stack

- JavaScript / Node.js
- YAML
- Playwright
- REST API
- CLI Automation
